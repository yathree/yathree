<div id="sidebar-menu">
        
    <ul>

	<li class="submenu">
            <a class="active" href="index.php"><i class="fa fa-fw fa-bars"></i><span> Dashboard </span> </a>
        </li>

        <li class="submenu">
            <a href="#"><i class="fa fa-fw fa-table"></i> <span> Usajili Wanachama </span> <span class="menu-arrow"></span></a>
                <ul class="list-unstyled">
                    <li><a href="index.php?h=registration">Sajili Mwanachama</a></li>
                    
			
		</ul>
        </li>
	 <li class="submenu">
            <a href="#"><i class="fa fa-fw fa-tv"></i> <span> Akiba </span> <span class="menu-arrow"></span></a>
                 <ul class="list-unstyled">
                    <li><a href="index.php?h=akiba">Taarifa Akiba</a></li>                   
			
		</ul>       
        </li>									
        <li class="submenu">
            <a href="#"><i class="fa fa-fw fa-tv"></i> <span> Amana </span> <span class="menu-arrow"></span></a>
              <ul class="list-unstyled">
                    <li><a href="index.php?h=amana">Taarifa Amana</a></li>                   
			
		</ul>                 
        </li>
        <li class="submenu">
            <a href="#"><i class="fa fa-fw fa-tv"></i> <span> Hisa</span> <span class="menu-arrow"></span></a>
             <ul class="list-unstyled">
                    <li><a href="index.php?h=hisa">Taarifa Hisa</a></li>                   
            
        </ul>         
        </li>
         <li class="submenu">
            <a href="#"><i class="fa fa-fw fa-tv"></i> <span> Mikopo</span> <span class="menu-arrow"></span></a>
             <ul class="list-unstyled">
                  
                    <li><a href="index.php?h=chukuwa_mkopo">Chukuwa Mkopo</a></li>
                    <!-- <li><a href="index.php?h=rejesha_mkopo">Rejesha Mikopo</a></li> -->
                    <li><a href="index.php?h=taarifa_mkopo">Taarifa za Mikopo</a></li>                   
            
        </ul>         
        </li>
        
         <li class="submenu">
            <a href="#"><i class="fa fa-fw fa-tv"></i> <span> Ubani</span> <span class="menu-arrow"></span></a>
             <ul class="list-unstyled">
                  
                   <li><a href="index.php?h=ubani">Toa ubani</a></li>       
                    <li><a href="index.php?h=taarifa_ubani">Maelezo ya Ubani</a></li>
                   
                              
            
        </ul>         
        </li>
        
        <li class="submenu">
             <a href="#"><i class="fa fa-fw fa-tv"></i> <span> Mapato</span> <span class="menu-arrow"></span></a>
             <ul class="list-unstyled">
                  
                   <li><a href="index.php?h=mapato">Sajili mapoto</a></li>
                   <li><a href="index.php?h=report_mapato">Report ya mapoto</a></li>
                   
                   
                              
            
        </ul> 
        </li>
        
	<li class="submenu">
            <a href="#"><i class="fa fa-cogs"></i> <span> System Settings </span> <span class="menu-arrow"></span></a>
                   <ul class="list-unstyled">
                    <li><a href="index.php?h=user_management">User Management</a></li>
                    <li><a href="index.php?h=aina_mikopo">Aina za mikopo</a></li>
                   
		</ul>          
        </li>
					
                    

					
					
                    

					                         
    </ul>
    
     <div class="clearfix"></div>

</div>