<?php

 switch((isset($_GET['h'])?$_GET['h'] : ''))
          {
     
          
          
          case 'user_management':
              include "user_management.php";
              break;
          
          case 'registration':
              include "registration.php";
              break;
          
           case 'akiba':
              include "akiba/akiba.php";
              break;
          
           case 'amana':
              include "amana/amana.php";
              break;
          
          case 'akiba_yako':
              include "akiba/akiba_yako.php";
              break;
          
          case 'amana_yako':
              include "amana/amana_yako.php";
              break;

          case 'hisa':
              include "hisa/hisa.php";
              break;
           
           case 'hisa_yako':
              include "hisa/hisa_yako.php";
              break;

           case 'aina_mikopo':
              include "mikopo/aina.php";
              break;
           
           case 'aina_mpya':
              include "mikopo/aina_mpya.php";
              break;
              
          case 'chukuwa_mkopo':
              include "mikopo/chukuwa_mkopo.php";
              break;
           
           case 'mikopo_yako':
              include "mikopo/mikopo_yako.php";
              break;

         case 'ubani':
             include "ubani/toaubani.php";
              break;
          case 'taarifa_ubani':
             include "ubani/taarifa.php";
              break;
           
           case 'mapato':
             include "mapato/sajili_mapato.php";
              break;
          
          case 'report_mapato':
              include "mapato/report_mapato.php";
              break;
              
         case 'taarifa_mkopo':
              include "mikopo/taarifa_mikopo.php";
              break;

         case 'taarifa_zake':
             include "mikopo/taarifa_zake.php";
             break;

        case 'mikopo_yake':
            include "mikopo/mikopo_yake.php";
            break;

          default:
              include "dashboard.php";
          }
?>
