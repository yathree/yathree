<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap/style.css">
<script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="bootstrap/css/popper.min.js"></script>

<title>blood</title>
<style>
.head {
    text-align:center;
    color:#152E56;
    /*background-color: #278adb;*/
    font-family: 'Ewert';
    font-weight: bold;
    text-shadow: 2px 2px 2px gray;
}

/*-----------------------------------------------tab color style-------------------------------------*/
.li1{
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
   /*background-color: #278adb;*/
}
li {
    float: left;
}

li a {
    display: block;
    color:blue;
    text-align: center;
    padding: 16px;
    text-decoration:none;
}
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

div.desc {
    padding: 15px;
    text-align: center;
}

* {
    box-sizing: border-box;
}

.responsive {
    padding: 0 6px;
    float: left;
    width: 24%;
}

@media only screen and (max-width: 700px){
    .responsive {
        width: 49%;
        margin: 6px 0;
    }
}

@media only screen and (max-width: 500px){
    .responsive {
        width: 100%;
    }
}

.clearfix:after {
    content: "";
    display: table;
    clear: both;
}


/*-------------------------ending style----------------------------------------------*/
</style>
</head>

<body>
  <!--=======================================header start===========================================-->

                 <div class="container-fluid" style="background: linear-gradient(to left,rgba(180,132,132,0.5)0%, #ffffff 100%);">
                     <div class="row">
                     <div class="col-sm-3"><img src="images/lgo1.jpeg" class="img-circle img-responsive" alt="logo" width="70%"></div>
                     <div class="col-sm-9"><h1 class="head">Zanzibar Blood Donation System</h1> </div>
                    
                     </div> <br>
                     <div class="li1">
                     <ul class="nav nav-tab">
                     <li><a href="#home" data-toggle="tab">Home</a></li>
                     <li><a href="#services" data-toggle="tab">Why Become Donor</a></li>
                     <li><a href="#services" data-toggle="tab">Become Donor</a></li>
                     <li><a href="#services" data-toggle="tab">Search Blood</a></li>
                     <li><a href="#services" data-toggle="tab">Where to donate</a></li>
                     <li><a href="#services" data-toggle="tab">Services</a></li>
                     <li><a href="#medias" data-toggle="tab">Media</a></li>
                     <li><a href="#about" data-toggle="tab">About Us</a></li>
                     <li><a href="#contact" data-toggle="tab">Contact Us</a></li>
                    
                     </ul>
                   </div>
                 </div>

  <!--======================================v1==========header end================================================-->
<div class="tab-content">

      <!--=====================v2===================home page staring==========================================-->
           
            <div id="home" class="tab-pane fade in active">
              <br>
                    <div class="container-fluid" style="background: linear-gradient(to left, rgba(180,132,132,0.5)0%, #ffffff 100%);">
                    <img src="images/img.jpg" clas="img-responsive" alt="HTML5 Icon" width="100%" height="500">
                    <br> <br> <br>
                    <section class="envor-section">
                    <div class="row" style="margin-top: 0px;">
                    <div class="col-sm-6">
                    <h1 style="margin-top: 0px; color:#152E56; text-align: center ">Welcome to Blood donation system  </h1>
                    <p style="text-align:center;font-size: 20px"><span style="color: #152E56; font-family: times">Blood Donation System</span><p>
                      Blood donation is the process of transferring
                      blood from a healthy person to someone who needsit. It "occurs when a person voluntarily has blooddrawn and used for transfusions and/or made intobiopharmaceutical medications by a process calledfractionation.”
                       </p>
                    <p>Blood donation is very important health careand blood is a very unique and precious resourcebecause it only can be obtained from blood donors.Donors participate to save many human beings eachyear, although some still die or suffer because of thelack of access to a safe blood transfusion (WHO,2010).</p>
                    </p>
                    <a data-toggle="pill" href="#about"><button type="button" class="btn btn-primary">learn more....<i class="fa fa-plus"></i></button></a>
                    </div>           
                    <div class="col-sm-6">
                    <figure class="single home"><img src="images/dnt.jpg" class="img-responsive" alt="" style="width: 99%; height: 350px;"></figure>
                    </div>
                    </div>
                    </section>
                    <hr>
                    <div class="col-sm-12">
                      <div class="line" style=" height: 3px; width: 99%; background-color: red; box-shadow: 5px 5px 5px #278adb;"></div>
                  </div>
                    <div class="col-sm-4">
                    <div class = "serv">
                    <h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Services</h2>
                    <img src="images/lgo1.jpeg" alt="HTML5 Icon" style="width: 99%; height: 200px;">
                    <p style=" text-align:justify;">Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
                    </p>
                    <a data-toggle="pill" href="#services"><button type="button" class="btn btn-primary">learn more....<i class="fa fa-plus"></i></button></a>
                    </div>
                    </div>
                    <div class="col-sm-4">
                    <div class = "prdt">
                   <h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Events</h2>      
                    <img src="images/lgo.jpeg" alt="HTML5 Icon" style="width: 99%; height: 200px;">
                    <p style=" text-align:justify;">Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
                    </p>
                    <a data-toggle="pill" href="#home"><button type="button" class="btn btn-primary">learn more....<i class="fa fa-plus"></i></button></a>
                    </div>
                    </div>
                    <div class="col-sm-4">
                    <div class = "prjt">
                   <h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Donor</h2>
                   <img src="images/nbts-logo.jpg" alt="HTML5 Icon" style="width: 99%; height: 200px;">
                    <p style=" text-align:justify;">Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
                    .</p>
                    <a data-toggle="pill" href="#home"><button type="button" class="btn btn-primary">learn more....<i class="fa fa-plus"></i></button></a>
                    </div>
                    </div>
                </div>
                
          </div>            

<!--============================ending home page====================-->



 <br>
  <div class="container-fluid" style=" background: linear-gradient(to left,rgb(180,132,132) 20%, rgb(227,138,134) 90%);"> 
    
                    <div class="map">
                    <div class="col-sm-9">
                      <!-- Add Google Maps -->
        <div id="googleMap" style="height:400px;width:100%;"></div>
        <script>
        function myMap() {
        var myCenter = new google.maps.LatLng(-6.199429, 39.306804);
        var mapProp = {center:myCenter, zoom:16, scrollwheel:false, draggable:false, mapTypeId:google.maps.MapTypeId.ROADMAP};
        var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
        var marker = new google.maps.Marker({position:myCenter});
        marker.setMap(map);
        }
        </script>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyABmRwI3UhBNf2rXADhOwBNN-dgjFlCW24&callback=myMap"></script>
        <!--
        To use this code on your website, get a free API key from Google.
        Read more at: https://www.w3schools.com/graphics/google_maps_basic.asp
        -->
                    </div>
                    <div class="col-sm-3">
                    <div class="envor-widget envor-contacts-2-widget">
                    <h3><b>contacts us</b></h3>
                    <div class="envor-widget-inner">
                    <p><div class="lbl"><b>Address : </b></div>
                   <span> <div class="content"> Blood donation system
                    <br>P.O. Box 1111 ,<br>Suza St, <br>Zanzibar-Tanzania
                    </div> </span></p>
                    <p><div class="lbl"><b>Phone :</b></div> <div class="content">+255777777777
                    <br>+255777888888
                    <br>
                  </div> </p>
                    <p><div class="lbl"><b>Email :</b></div> <div class="content"><a href="">info@bloddonation.com</a></div> </p>
                    </div>
                    </div>
                    </div>
                    </div>
                 
                  <div class="col-sm-12">
                      <div class="line" style=" height: 5px; background-color: #cccccc;"></div>
                  </div>
                 <div class="col-sm-12">
                    <p style="color:#152E56; text-align: center;  background: linear-gradient(to left,rgb(180,132,132) 20%, rgb(227,138,134) 90%);" > 
                      <a href="#">Blood Donation System</a>.<br> © Copyright 2020</p></div>
               </div>


</div>
  </body>
  </html>
