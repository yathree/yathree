
 <style type="text/css">
  * {
    box-sizing: border-box;
    font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
    font-size: 16px;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.login {
    width: 400px;
    background-color: #ffffff;
    box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
    margin: 80px auto;
}
.login h1 {
    text-align: center;
    color: #5b6574;
    font-size: 24px;
    padding: 20px 0 20px 0;
    border-bottom: 1px solid #dee0e4;
}
.login form {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    padding-top: 20px;
}
.login form label {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 50px;
    height: 50px;
    background-color: #3274d6;
    color: #ffffff;
}
.login form input[type="password"], .login form input[type="text"], .login form input[type="email"] {
    width: 310px;
    height: 50px;
    border: 1px solid #dee0e4;
    margin-bottom: 20px;
    padding: 0 15px;
}
.login form input[type="submit"] {
    width: 100%;
    padding: 15px;
    margin-top: 20px;
    background-color: #3274d6;
    border: 0;
    cursor: pointer;
    font-weight: bold;
    color: #ffffff;
    transition: background-color 0.2s;
}

.login form button{
    width: 100%;
    padding: 15px;
    margin-top: 15px;
    margin-bottom:5px;
    background-color: #3274d6;
    border: 0;
    cursor: pointer;
    font-weight: bold;
    color: #ffffff;
    transition: background-color 0.2s;
}
.login form input[type="submit"]:hover {
  background-color: #2868c7;
    transition: background-color 0.2s;
}
  
</style>


    <div class="login">
      <h1>Sing up for new donnor</h1>
      <form action="registerHandler.php" method="post">
        <label for="fullname">
          <i class="fas fa-user"></i>
        </label>
        <input type="text" name="fullname" placeholder="Full Name" id="fullname" required>
        <label for="donorID">
          <i class="fas fa-user"></i>
        </label>
        <input type="text" name="donorID" placeholder="Donation ID" id="donorID" required>
        <label for="email">
          <i class="fas fa-envelope"></i>
        </label>
        <input type="email" name="email" placeholder="user email" id="email" required>
        <label for="password">
          <i class="fas fa-lock"></i>
        </label>
        <input type="password" name="password" placeholder="Password" id="password" required>
        <button type="submit" class="btb btn-default" name="btn-reg"> Sign Up </button> 
      </form>

      	 <p align ="center">Do you have an account? <a href="#login" id="back" >Login</a></p>
		  <script>
    	$(document).ready(function(){

    		$("#back").click(function(){
    			$("#content").load("login.php")
    		});
    	});
    </script>
    </div>