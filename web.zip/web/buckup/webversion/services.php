<div class="col-sm-12">
<div class="col-sm-4">
<div class = "serv">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Services</h2>
<img src="images/lgo1.jpeg" alt="HTML5 Icon" style="width: 99%; height: 200px;">
<p style=" text-align:justify;">Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
</p>

</div>
</div>
<div class="col-sm-4">
<div class = "prdt">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Events</h2>      
<img src="images/lgo.jpeg" alt="HTML5 Icon" style="width: 99%; height: 200px;">
<p style=" text-align:justify;">Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
</p>

</div>
</div>
<div class="col-sm-4">
<div class = "prjt">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Donor</h2>
<img src="images/nbts-logo.jpg" alt="HTML5 Icon" style="width: 99%; height: 200px;">
<p style=" text-align:justify;">Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
.</p>

</div>
</div>

</div>

    <div class="col-sm-12">
                      <div class="line" style=" height: 3px; width: 99%; background-color: red; box-shadow: 5px 5px 5px #278adb;">
                           
                      </div>

                  </div> 
<div class="col-sm-12">
<div class="col-sm-4">
<div class = "serv">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Services</h2>
<img src="images/lgo1.jpeg" alt="HTML5 Icon" style="width: 99%; height: 200px;">
<p style=" text-align:justify;">Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
</p>

</div>
</div>
<div class="col-sm-4">
<div class = "prdt">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Events</h2>      
<img src="images/lgo.jpeg" alt="HTML5 Icon" style="width: 99%; height: 200px;">
<p style=" text-align:justify;">Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
</p>

</div>
</div>
<div class="col-sm-4">
<div class = "prjt">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Donor</h2>
<img src="images/nbts-logo.jpg" alt="HTML5 Icon" style="width: 99%; height: 200px;">
<p style=" text-align:justify;">Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
.</p>

</div>
</div>
</div>