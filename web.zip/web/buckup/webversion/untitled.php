















############importance of donation #####################

• it carries oxygen to all parts of the body and removes carbon dioxide
• it provides nutrients to the body’s cells
• it provides defence against diseases
• it replaces blood lost from accidents and child birth I would like to encourage all of you to become involved and committed to saving lives. Even if you can’t donate, please encourage others (friends, family) to donate blood.


################ who need blood #################
It is a great feeling to knowing that by donating a unit of blood you have helped
• a mother during complicated child birth
• a sick baby
• a badly injured accident victim
• a patient being treated for cancer
• patients needing major operations
• patients with severe burns
• The life you save may be yours!
• blood is life


################# why donate #####################

We donate to help people who need a blood transfusion. The act of blood donation produces a feeling of goodwill and a wonderful sense of achievement. It feels really good to think that your actions are directly responsible for saving someone’s life. The gift of life means the difference between life and death for someone. One day that someone may be a close relative, personal friend, a loved one or yourself. 

############ who donate #################
We would like to invite people who have a strong desire to help save a life by donating blood. They must be honest people who will readily admit if they have any health condition which prevents them from donating.