<?php
include("connection.php");

if(isset($_POST["btn-reg"])){

	$fullname=$con->real_escape_string($_POST["fullname"]);
	$donorID=$con->real_escape_string($_POST["donorID"]);
	$password=$con->real_escape_string($_POST["password"]);
	$email=$con->real_escape_string($_POST["email"]);

	$check=$con->query("SELECT * FROM users WHERE email='$email'")or die($con->error);
	$n=$check->num_rows;

	if($n==0){
	
	// $con->query("INSERT INTO users (username,passwords, email,donorID) 
	 	//VALUES('$fullname','$password','$email','$donorID')")or die($con->error);
 	
 	?>
 		  <script>
			alert('successfully registered');
	        window.location.href='index.php';
          </script>

 	<?php
	}
	else{
		?>
 		  <script>
			alert('registed data exist');
	        window.location.href='index.php';
          </script>

 	<?php
	}
}
?>
	