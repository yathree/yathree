<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include"../connection.php";
session_start();


    if ( ! isset($_GET['id']) ) {
     
      header('Location: orderblood.php');
      return;
    }
    


        $sql = "UPDATE blood_order SET status = :status
                WHERE bo_ID = :bo_ID";
        $stmt = $con->prepare($sql);
        $stmt->execute(array(
            ':status' => 'accepted',
            ':bo_ID' => $_GET['id']));
        $_SESSION['msg'] = 'Order Accepted';
        header( 'Location: orderblood.php' ) ;
        return;

?>