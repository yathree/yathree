<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("../connection.php");


if(isset($_GET["id"])){


		$sql = "UPDATE donor SET status= :status
				 WHERE d_ID = :d_ID ";
				

		$stmt=$con->prepare($sql);

		$stmt-> execute(array(
			':status' => 'blocked',
			':d_ID' => $_GET["id"]));

 	?>
 		  <script>
			alert('successfully Block donor');
	        window.location.href='donor.php';
          </script>

 	<?php
	}
	else{
		?>
 		  <script>
			alert('Choose specific donor');
	        window.location.href='donor.php';
          </script>

 	<?php
	}
?>
	