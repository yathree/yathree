<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include"../connection.php";
session_start();

if(!isset($_SESSION['USER'])){
    header("location:../index.php");
}
?>

<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php
    include ('link.php');
?>

<title>blood</title>
<?php
    include ('head.php');
?>
<body class="container">

  <!--====================================header start=====================================-->

                 <?php 
                    include ('menu.php');
                  
                  ?>

  <!--=========================================header end=============================================-->

<div class="tab-content">

      <!--======================================home page staring=====================================-->
           
            <div id="home" class="tab-pane fade in active">
              <br>
                    <div class="container-fluid" id="content" style="background: linear-gradient(to left, rgba(180,132,132,0.5)0%, #ffffff 100%);">
                        

                         <div class="container">
        <?php
            if ( isset($_SESSION['msg']) ) {

        ?>
                <!-- <script>
                    alert('Action successfully');
                   
                </script> -->

            <?php
                echo '<p style="color:red; text-align:center">'.$_SESSION['msg']."</p>\n";
                unset($_SESSION['msg']);
            }
        ?>                          
         
<br>

                          <h2>List of order</h2>                                                                                      
                          
                          <div class="table-responsive">
                            <table class="table table-bordered">
                              
                              <?php
                                    if($_SESSION['USER']=='admin'){

                                  ?>

                                  <thead>
                                <tr>
                                  <th>#</th>
                                  <th>Card number</th>
                                  <th>Issue date</th>
                                  <th>Blood</th>
                                  <th>Hospital</th>
                                  <th>Reason</th>
                                  <th>Status</th>
                                  <th>Action</th>  
                                </tr>
                              </thead>

                              <tbody>
                              <?php

                                  $count=1;

                                  $stmt = $con->query("SELECT * FROM  blood_order inner join hospital using(h_ID) order by 'date'");

                                  while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {

                              ?>

                              
                                <tr>
                                  
                                  <td> <?php echo $count ?> </td>
                                  <td> <?php echo($row['card']) ?> </td>
                                  <td> <?php echo($row['dates']) ?> </td>
                                  <td> <?php echo($row['bloodgroup']) ?> </td>
                                  <td> <?php echo($row['name']) ?> </td>
                                  <td> <?php echo($row['reason']) ?> </td>
                                  <td> <?php echo($row['status']) ?> </td>

                                 
                                  <td> <?php  echo('<a href=accept.php?id='.$row['bo_ID'].'>Accept</a>') ?> <?php  echo('<a href=ignore.php?id='.$row['bo_ID'].'>Ignore</a>') ?>
                                   </td>

                                 
                                  
                                </tr>
                                <?php
                                 $count++;
                                     }

                                ?>
                              </tbody>




                                <?php
                                  }else{
                                ?>


                              <thead>
                                <tr>
                                  <th>#</th>
                                  <th>Card number</th>
                                  <th>Issue date</th>
                                  <th>Blood</th>
                                  <th>Hospital</th>
                                  <th>Reason</th>
                                  <th>Status</th>
                                 
                                </tr>
                              </thead>

                              <tbody>
                              <?php

                                  $count=1;
                                  $donor= $_SESSION['USER'];
                                  $stmt = $con->query("SELECT * FROM  blood_order inner join hospital using(h_ID) WHERE card ='$donor' order by 'date'");

                                  while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {

                              ?>

                              
                                <tr>
                                  
                                  <td> <?php echo $count ?> </td>
                                  <td> <?php echo($row['card']) ?> </td>
                                  <td> <?php echo($row['dates']) ?> </td>
                                  <td> <?php echo($row['bloodgroup']) ?> </td>
                                  <td> <?php echo($row['name']) ?> </td>
                                  <td> <?php echo($row['reason']) ?> </td>
                                  <td> <?php echo($row['status']) ?> </td>
                                  
                                </tr>
                                <?php
                                 $count++;
                                     }

                                ?>
                              </tbody>

                            <?php } ?>
                            </table>




                          </div>
                        </div>






                </div>




                
          </div>            

<!--============================ending home page====================-->



          <?php 
            include ('footer.php');
          
          ?>


</div>

</body>

</html>
