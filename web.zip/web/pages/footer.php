

<br>
  <div class="container-fluid" style=" background: linear-gradient(to left,rgb(180,132,132) 20%, rgb(227,138,134) 90%);"> 

    <div class="col-sm-12">
        <div class="line" style=" height: 5px; background-color: #cccccc;"></div>
    </div>

   <div class="col-sm-12">
      <p style="color:#152E56; text-align: center;  background: linear-gradient(to left,rgb(180,132,132) 20%, rgb(227,138,134) 90%);" > 
        <a href="#">Blood Donation System</a>.<br> © Copyright 2020</p>
    </div>
 </div>
