<head>
<style>

* {
    box-sizing: border-box;
    font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
    font-size: 16px;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.head {
    /*text-align:center;*/
    color:#152E56;
    /*background-color: #278adb;*/
    font-family: 'Ewert';
    font-weight: bold;
    text-shadow: 2px 2px 2px gray;
}

/*-----------------------------------------------tab color style-------------------------------------*/
.li1{
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
   /*background-color: #278adb;*/
}
li {
    float: left;
}

li a {
    display: block;
    color:blue;
    text-align: center;
    padding: 16px;
    text-decoration:none;
}
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

div.desc {
    padding: 15px;
    text-align: center;
}

* {
    box-sizing: border-box;
}

.responsive {
    padding: 0 6px;
    float: left;
    width: 24%;
}

@media only screen and (max-width: 700px){
    .responsive {
        width: 49%;
        margin: 6px 0;
    }
}

@media only screen and (max-width: 500px){
    .responsive {
        width: 100%;
    }
}

.clearfix:after {
    content: "";
    display: table;
    clear: both;
}


/*-------------------------ending style-----------------------------------*/
</style>
</head>