<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include"../connection.php";
session_start();

if(!isset($_SESSION['USER'])){
    header("location:../index.php");
}
?>

<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php
    include ('link.php');
?>
<title>blood</title>

<?php
    include ('head.php');
?>

<body class="container">
  <!--====================================header start=====================================-->

                  <?php 
                    include ('menu.php');
                  
                  ?>
  <!--=========================================header end=============================================-->

<div class="tab-content">

      <!--======================================home page staring=====================================-->
           
            <div id="home" class="tab-pane fade in active">
              <br>
                    <div class="container-fluid" id="content" style="background: linear-gradient(to left, rgba(180,132,132,0.5)0%, #ffffff 100%);">
                    <div class="container">
 

                          <h2>List of blood donor</h2>                                                                                      
                          
                          <div class="table-responsive">
                            <table class="table table-bordered">
                              <thead>
                                <tr>
                                  <th>#</th>
                                  <th>Full Name</th>  
                                  <th>Address</th>
                                  <th>Phone Number</th>
                                  <th>Email</th>
                                  <th>Blood Group</th>
                                  <?php
                                    if ($_SESSION['USER']=='admin'){
                                  ?>
                                  <th>Gender</th>
                                  <th>Status</th>
                                  <th> Action </th>
                                  <?php
                                    }
                                  ?>
                                </tr>
                              </thead>

                              <tbody>
                              <?php

                                  $count=1;
                                  $stmt = $con->query("SELECT * FROM donor");
                                  while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {

                              ?>

                              
                                <tr>
                                  <td> <?php echo $count ?> </td>
                                  <td> <?php echo($row['fullName']) ?> </td>
                                  <td> <?php echo($row['address']) ?> </td>
                                  <td> <?php echo($row['phone']) ?> </td>
                                  <td> <?php echo($row['email']) ?> </td>
                                  <td> <?php echo($row['bloodtype']) ?> </td>

                                  <?php
                                    if ($_SESSION['USER']=='admin'){
                                  ?>
                                   <td> <?php echo($row['gender']) ?> </td>
                                  <td> <?php echo($row['status']) ?> </td>
                                  
                                  <td> <?php  echo('<a href=editdonor.php?id='.$row['d_ID'].'>Edit</a>') ?>
                                       <?php  echo('<a href=blockdonor.php?id='.$row['d_ID'].'>Block</a>') ?>
                                       <?php  echo('<a href=activatedonor.php?id='.$row['d_ID'].'>activate</a>') ?>
                                  </td>
              
                                  <?php
                                    }
                                  ?>
                                 
                                </tr>
                                <?php
                                 $count++;
                                     }

                                ?>
                              </tbody>
                            </table>
                          </div>
                        </div>







                </div>
                
          </div>            

<!--============================ending home page====================-->



          <?php 
            include ('footer.php');
          
          ?>



</div>

</body>

</html>
