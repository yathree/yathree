<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("../connection.php");


if(isset($_POST["btnsubmit"])){


		$sql = "INSERT INTO blood_store (date_issue,d_ID) 
				VALUES(:date_issue, :d_ID)";

		$stmt=$con->prepare($sql);

		$stmt-> execute(array(
			':d_ID' => $_POST["d_ID"],
			':date_issue' => $_POST["date"]));


 	?>
 		  <script>
			alert('update successfully');
	        window.location.href='blood.php';
          </script>

 	<?php
	}
	else{
		?>
 		  <script>
			alert('Not Updated');
	        window.location.href='blood.php';
          </script>

 	<?php
	
}
?>
	