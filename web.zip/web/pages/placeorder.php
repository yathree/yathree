<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("../connection.php");


if(isset($_POST["btnsubmit"])){


		$sql = "INSERT INTO blood_order (h_ID,dates,reason,card,bloodgroup) 
				VALUES(:h_ID, :dates, :reason, :card, :bloodgroup)";

		$stmt=$con->prepare($sql);

		$stmt-> execute(array(
			':h_ID' => $_POST["hosp"],
			':dates' => $_POST["date"],
			':reason' => $_POST["reason"],
			':card' => $_POST["card"],
			':bloodgroup' => $_POST["bloodgroup"]));


 	?>
 		  <script>
			alert('order submited successfully');
	        window.location.href='home.php';
          </script>

 	<?php
	}
	else{
		?>
 		  <script>
			alert('order not submited');
	        window.location.href='home.php';
          </script>

 	<?php
	
}
?>
	