<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include"../connection.php";
session_start();
if(!isset($_SESSION['USER'])){
    header("location:../index.php");
}
?>

<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

        <?php
            include ('link.php');
        ?>
<title>blood</title>

        <?php
            include ('head.php');
        ?>

<body class="container">

  <!--====================================header start=====================================-->

         <?php 
            include ('menu.php');
          
          ?>
  <!--=========================================header end=============================================-->

<div class="tab-content">

      <!--======================================home page staring=====================================-->
           
            <div id="home" class="tab-pane fade in active">
              <br>
                    <div class="container-fluid" id="content" style="background: linear-gradient(to left, rgba(180,132,132,0.5)0%, #ffffff 100%);">
                    






                </div>
                
          </div>            

<!--============================ending home page====================-->



          <?php 
            include ('footer.php');
          
          ?>


</div>

</body>

</html>
