<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include"../connection.php";
session_start();


if(!isset($_SESSION['USER'])){
    header("location:../index.php");
}
?>

<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php
    include ('link.php');
?>
<title>blood</title>

<?php
    include ('head.php');
?>

<body class="container">

  <!--====================================header start=====================================-->

                 <?php 
                    include ('menu.php');
                  
                  ?>
  <!--=========================================header end=============================================-->

<div class="tab-content">

      <!--======================================home page staring=====================================-->
           
            <div id="home" class="tab-pane fade in active">
              <br>
                    <div class="container-fluid" id="content" style="background: linear-gradient(to left, rgba(180,132,132,0.5)0%, #ffffff 100%);">
                        

                         <div class="container">



                            <!-- Button to Open the Modal -->
                            <br> 
              <?php
                    if ($_SESSION['USER']=='admin'){

              ?>
              <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#Modal1">
                UPDATE STOREE
              </button>

              <?php
                } else{
              ?>

                <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal">
                  Order blood
                </button>

                <?php
                    }
                ?> 

<br>

                          <h2>List of blood in store</h2>                                                                                      
                          
                          <div class="table-responsive">
                            <table class="table table-bordered">
                              <thead>
                                <tr>
                                  <th>#</th>
                                  <th>Blood Group</th>
                                <!--   <th>Card Number</th> -->
                                  <th>Issue date</th>
                                  <th>Status</th>
                                  
                                </tr>
                              </thead>

                              <tbody>
                              <?php

                                  $count=1;
                                  $stmt = $con->query("SELECT * FROM donor inner join blood_store using(d_ID) order by date_issue DESC");

                                  while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {

                              ?>

                              
                                <tr>
                                  <td> <?php echo $count ?> </td>
                                  <td> <?php echo($row['bloodtype']) ?> </td>
                                 
                                  <td> <?php echo($row['date_issue']) ?> </td>
                                  <td> <?php echo($row['status']) ?> </td>
                                  
                                </tr>
                                <?php
                                 $count++;
                                     }

                                ?>
                              </tbody>
                            </table>
                          </div>
                        </div>






                </div>



                <!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Order Blood</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       
      <form method="post" action="placeorder.php">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Card Number</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" name="card" value="<?php echo $_SESSION['USER'] ?>" placeholder="Enter card number" readonly required="">
                          </div>

                          <div class="form-group">
                            <label for="exampleInputEmail1">Date placed</label>
                            <input type="date" class="form-control" id="exampleInputEmail1" name="date" placeholder="Enter date" required="">
                          </div>

                          <div class="form-group">
                            <label for="exampleInputEmail1">Hospital</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="hosp" required="">
                                 <option value="" disabled selected hidden > Choose Hospital</option>
                                 <?php

                                  
                                  $hospital = $con->query("SELECT *  FROM hospital");

                                  while ( $hosp = $hospital->fetch(PDO::FETCH_ASSOC) ) {
                                    $hospt = $hosp['h_ID'];

                              ?>
                              <option value="<?php echo $hospt ?>"><?php echo($hosp['name']) ?></option>
                             
                             <?php
                                 
                                     }

                                ?>
                            </select>
                            
                          </div>
                           <div class="form-group">
                            <label for="exampleFormControlSelect1">Choose blood</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="bloodgroup" required="">
                                 <option value="" disabled selected hidden > Choose blood type </option>
                                <?php

                                  
                                  $blood = $con->query("SELECT distinct bloodtype  FROM donor inner join blood_store using(d_ID) where blood_store.status ='available'");

                                  while ( $blod = $blood->fetch(PDO::FETCH_ASSOC) ) {
                                    $bloodty = $blod['bloodtype'];

                              ?>
                              <option value="<?php echo $bloodty ?>"><?php echo($blod['bloodtype']) ?></option>
                             
                             <?php
                                 
                                     }

                                ?>
                            </select>
                          </div>
                          <div class="form-group">
                            <label for="exampleInputText">Reason</label>
                            <input type="text"name="reason" class="form-control" id="exampleInputText" placeholder="reason for need blood" required="">
                          </div>
                          
                          <button type="submit" name="btnsubmit"class="btn btn-primary">Submit</button>
                        </form>

 <!-- $stm = $con->query("SELECT distinct bloodtype  FROM donor inner join blood_store using(d_ID) where status ='available'"); -->





      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
          

                <!-- The Modal -->
<div class="modal" id="Modal1">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Order Blood</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       
      <form method="post" action="updatestore.php">
                          

                          <div class="form-group">
                            <label for="exampleInputEmail1">Donor Card</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="d_ID" required="">
                                 <option value="" disabled selected hidden > Choose Card number</option>
                                 <?php

                                  
                                  $donor = $con->query("SELECT *  FROM donor");

                                  while ( $dono = $donor->fetch(PDO::FETCH_ASSOC) ) {
                                    $don = $dono['d_ID'];

                              ?>
                              <option value="<?php echo $don ?>"><?php echo($dono['cardno']) ?></option>
                             
                             <?php
                                 
                                     }

                                ?>
                            </select>
                            
                          </div>
                           
                          <div class="form-group">
                            <label for="exampleInputText">Donated date</label>
                            <input type="date"name="date" class="form-control" id="exampleInputText" placeholder="donate date " required="">
                          </div>
                          
                          <button type="submit" name="btnsubmit"class="btn btn-primary">Submit</button>
                        </form>

 <!-- $stm = $con->query("SELECT distinct bloodtype  FROM donor inner join blood_store using(d_ID) where status ='available'"); -->





      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>    
          </div>            

<!--============================ending home page====================-->



          <?php 
            include ('footer.php');
          
          ?>



</div>

</body>

</html>
