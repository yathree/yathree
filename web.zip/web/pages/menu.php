



<div class="container-fluid" style="background: linear-gradient(to left,rgba(180,132,132,0.5)0%, #ffffff 100%);">
     <div class="row">
         <div class="col-sm-3"><img src="../images/lgo1.jpeg" class="img-circle img-responsive" alt="logo" width="70%"></div>
             <div class="col-sm-9"><h1 class="head">Zanzibar Blood Donation System</h1> </div>
            
             </div> <br>
         <div class="li1">
             <ul class="nav nav-tab">

               <?php
                    if ($_SESSION['USER']=='admin'){

              ?>
                     <li><a href="home.php">Home </a></li>
                     <li><a href="donor.php">Manage Donor</a></li>
                     <li><a href="blood.php">Update Store</a></li>
                     <li><a href="orderblood.php">Orders</a></li>
                     <li><a href="../logout.php">Logout</a></li>  

              <?php
                } else{
              ?>


                 <li><a href="home.php">Home </a></li>
                 <li><a href="donor.php">Donors</a></li>
                 <li><a href="blood.php">Blood Store</a></li>
                 <li><a href="orderblood.php">View order</a></li>
                 <li><a href="../logout.php">Logout</a></li>    

                <?php
                    }
                ?>  
             </ul>

   </div>
</div>