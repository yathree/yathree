<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include"../connection.php";
session_start();

if(!isset($_SESSION['USER'])){
    header("location:../index.php");
}
?>

<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php
    include ('link.php');
?>

<title>blood</title>
<?php
    include ('head.php');
?>

<body class="container">

  <!--====================================header start=====================================-->

                  <?php 
                    include ('menu.php');
                  
                  ?>

  <!--=========================================header end=============================================-->

<div class="tab-content">

      <!--======================================home page staring=====================================-->
           
            <div id="home" class="tab-pane fade in active">
              <br>
                    <div class="container-fluid" id="content" style="background: linear-gradient(to left, rgba(180,132,132,0.5)0%, #ffffff 100%);">

<div>

<?php
            if ( ! isset($_GET['id']) ) {
              $_SESSION['error'] = "Missing user_id";
              header('Location: donor.php');
              return;
            }

            $stmt = $con->prepare("SELECT * FROM donor where d_ID = :d_ID");
            $stmt->execute(array(":d_ID" => $_GET['id']));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

             $fullName=$row['fullName'];
             $address=$row['address'];
             $gender=$row['gender'];
             $dob=$row['DoB'];
             $phone=$row['phone'];
             $email=$row['email'];
             $card=$row['cardno'];
             $blood=$row['bloodtype'];
             $d_ID= $_GET['id'];
                                   
            if ( $row === false ) {
                $_SESSION['error'] = 'Bad value for user_id';
                header( 'Location: donor.php' ) ;
                return;
}

?>

<br>
                    <form method="post" action="updatedonor.php">
                          <div class="row">
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Full Name</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter email ?>" name="fname" value="<?php echo $fullName?>" required="">
                           
                          </div>
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1"> Address</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter email" name="address" value="<?php echo $address?>" required="">
                            
                          </div>
                      </div>

                      <div class="row">
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Gender</label>
                            
                            <select class="form-control" name="gender" id="exampleFormControlSelect1" required="">
                            
                            <option value="<?php echo $gender?>" > <?php echo $gender ?> </option>
                                 
                              <option value="M"> Male </option>
                              <option value="F"> Female</option>
                            
                            </select>

                          </div>
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Date of Birth</label>
                            <input type="date" class="form-control" id="exampleInputEmail1" placeholder="date of birth" name="dob" value="<?php echo $dob?>" required="">
                            
                          </div>

                      </div>
                      <div class="row"> 
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Phone Number</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" placeholder="valid phone number" name="phone" value="<?php echo $phone?>" required="">
                            
                          </div>
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1"> Email address</label>
                            <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" name="email" value="<?php echo $email?>" required="">
                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                          </div>
                          </div>

                          <div class="row">
                           <div class="col-sm-6 form-group">
                            <label for="exampleInputText">Card Number</label>
                            <input type="text" class="form-control" id="exampleInputText" placeholder="reason for need blood"  name="card" value="<?php echo $card?>"required="">
                          </div>
                          <div class="col-sm-6 form-group">

                            <label for="exampleFormControlSelect1">Blood type</label>
                            <select class="form-control" name="bloodtype" id="exampleFormControlSelect1" required="">
                                 <option value="<?php echo $blood ?>" > <?php echo $blood ?> </option>
                                 
                              <option value="A"> A </option>
                              <option value="B+"> B+ </option>
                              <option value="B-"> B- </option>
                              <option value="O+"> O+</option>
                              <option value="O-"> O-</option>
                              <option value="AB+"> AB+ </option>
                              <option value="AB-"> AB- </option>
                             
                            
                            </select>

                          </div>
                      </div>
                          <input type="hidden" name="d_ID" value=" <?php echo $d_ID ?>">
                          <button type="submit" name="btnsubmit" class="btn btn-primary">Submit</button>

                          <a type="submit" href="donor.php" class="btn btn-info ">Cancel</a>
                      
                        </form>
<br>

</div>

                </div>
                
          </div>            

<!--============================ending home page====================-->



           <?php 
            include ('footer.php');
          
          ?>



</div>

</body>

</html>
