


<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../bootstrap/style.css">
<link rel="stylesheet" type="text/css" href="../bootstrap/datatable/jquery.dataTable.min.css">
<script type="text/javascript" src="../bootstrap/datatable/jquery.dataTable.min.js"></script>
<script type="text/javascript" src="../bootstrap/js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../bootstrap/js/popper.min.js"></script>


<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">