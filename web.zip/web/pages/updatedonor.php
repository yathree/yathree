<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("../connection.php");


if(isset($_POST["btnsubmit"])){


		$sql = "UPDATE donor SET fullname= :fullname,
				 address= :address, 
				 gender= :gender, 
				 dob= :dob, 
				 phone= :phone,
				 email= :email,
				 cardno= :cardno,
				 bloodtype= :bloodtype
				 WHERE d_ID = :d_ID ";
				

		$stmt=$con->prepare($sql);

		$stmt-> execute(array(
			':fullname' => $_POST["fname"],
			':address' => $_POST["address"],
			':gender' => $_POST["gender"],
			':dob' => $_POST["dob"],
			':phone' => $_POST["phone"],
			':email' => $_POST["email"],
			':cardno' => $_POST["card"],
			':bloodtype' => $_POST["bloodtype"],
			':d_ID' => $_POST["d_ID"]));

 	?>
 		  <script>
			alert('successfully updated');
	        window.location.href='donor.php';
          </script>

 	<?php
	}
	else{
		?>
 		  <script>
			alert('Choose specific donor');
	        window.location.href='donor.php';
          </script>

 	<?php
	}
?>
	