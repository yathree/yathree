<?php

$con= new PDO('mysql:host=localhost;dbname=web','root','Ya3@haji2020');

//echo "succ";

$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);



?>