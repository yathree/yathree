    <div class="container">
      <h1 style="text-align: center;">Sing up for new donnor</h1>
      <br>
       <form method="post" action="add_donor.php" autocomplete="off">

        <div class="row">
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Full Name</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter full name" name="fname" required="">
                           
                          </div>
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1"> Address</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter address"name="address"required="">
                            
                          </div>
                      </div>

                      <div class="row">
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Gender</label>
                            
                            <select class="form-control" id="exampleFormControlSelect1" name="gender" required="">
                            
                            <option value="" disabled selected hidden > Choose gender </option>
                                 
                              <option value="M"> Male </option>
                              <option value="F"> Female</option>
                            
                            </select>

                          </div>
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Date of Birth</label>
                            <input type="date" class="form-control" id="exampleInputEmail1" placeholder="date of birth" name="dob" required="">
                            
                          </div>

                      </div>
                      <div class="row"> 
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Phone Number</label>
                            <input type="number" min="0" class="form-control" id="exampleInputEmail1" placeholder="valid phone number" name="phone" required="">
                            
                          </div>
                          <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1"> Email address</label>
                            <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" name="email" required="">
                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                          </div>
                          </div>

                          <div class="row">
                           <div class="col-sm-6 form-group">
                            <label for="exampleInputText">Card Number</label>
                            <input type="text" class="form-control" id="exampleInputText" placeholder="Donor card number"  name="card" required="">
                          </div>
                          <div class="col-sm-6 form-group">

                            <label for="exampleFormControlSelect1">Blood type</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="bloodtype" required="">
                                 <option value="" disabled selected hidden > Choose your blood group </option>
                                 
                              <option value="A"> A </option>
                              <option value="B+"> B+ </option>
                              <option value="B-"> B- </option>
                              <option value="O+"> O+</option>
                              <option value="O-"> O-</option>
                              <option value="AB+"> AB+ </option>
                              <option value="AB-"> AB- </option>
                             
                            
                            </select>

                          </div>
                      </div>
                          
                          <button type="submit" name="btnsubmit" class="btn btn-primary">Submit</button>

                        
        
      </form>

      	 <p align ="center">Do you have an account? <a href="#login" id="back" >Login</a></p>
		  <script>
    	$(document).ready(function(){

    		$("#back").click(function(){
    			$("#content").load("login.php")
    		});
    	});
    </script>
    </div>