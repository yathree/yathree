<div class="col-sm-12">
<div class="col-sm-4">
<div class = "serv">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Blood Testing</h2>

<p style=" text-align:justify;"><br> Service has evolved from a hospital-based system relying on  80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
</p>

</div>
</div>
<div class="col-sm-4">
<div class = "prdt">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Blood Donation</h2>      
<p style=" text-align:justify;"><br> Service has evolved from a hospital-based system relying on  80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
</p>

</div>
</div>
<div class="col-sm-4">
<div class = "prjt">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Blood Order</h2>
<p style=" text-align:justify;"><br> Service has evolved from a hospital-based system relying on  80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
.</p>

</div>
</div>

</div>

    			<div class="col-sm-12">
                      <div class="line" style=" height: 3px; width: 99%; background-color: red; box-shadow: 5px 5px 5px #278adb;">
                           
                      </div>
                  </div> 


<div class="col-sm-12">
<div class="col-sm-4">
<div class = "serv">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Cancelling</h2>
<p style=" text-align:justify;"> <br> Service has evolved from a hospital-based system relying on  80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.


</p>

</div>
</div>
<div class="col-sm-4">
<div class = "prdt">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Advicing</h2>      

<p style=" text-align:justify;"><br> Service has evolved from a hospital-based system relying on  80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
</p>

</div>
</div>
<div class="col-sm-4">
<div class = "prjt">
<h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Store Blood</h2>

<p style=" text-align:justify;"><br> Service has evolved from a hospital-based system relying on  80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
.</p>

</div>
</div>
</div>