<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("connection.php");
session_start(); 


if(isset($_POST["btnlogin"])){
 
	   $username=$_POST["username"];
	   $password=$_POST["password"];

	$check=$con->query("SELECT * FROM users WHERE username='$username' and passwords='$password'")or die($con->error);
	
	$row = $check->fetch(PDO::FETCH_ASSOC);

	$check->rowCount();
	
				if($check->rowCount()==1){

			 		$data=$con->query("SELECT * FROM donor WHERE cardno='$username'")or die($con->error);
					$rows = $data->fetch(PDO::FETCH_ASSOC);

					$role = $row['username']; 

			 		$_SESSION['USER'] = $role; 
					

				 header('location: ../../web/pages/home.php');
				}

					else{
						header ('location : index.php');

					}

	}
	else{
	header ('location : index.php');
}
?>
	