<div class="map">
                    <div class="col-sm-12">
                      <!-- Add Google Maps -->

                      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyABmRwI3UhBNf2rXADhOwBNN-dgjFlCW24&callback=myMap"></script>
        <!--
        To use this code on your website, get a free API key from Google.
        Read more at: https://www.w3schools.com/graphics/google_maps_basic.asp
        -->
        <div id="googleMap" style="height:400px;width:100%;"></div>
        <script>
        function myMap() {
        var myCenter = new google.maps.LatLng(-6.199429, 39.306804);
        var mapProp = {center:myCenter, zoom:16, scrollwheel:false, draggable:false, mapTypeId:google.maps.MapTypeId.ROADMAP};
        var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
        var marker = new google.maps.Marker({position:myCenter});
        marker.setMap(map);
            }
        function myMap() {
        var myCenter = new google.maps.LatLng(-6.199429, 39.286804);
        var mapProp = {center:myCenter, zoom:16, scrollwheel:false, draggable:false, mapTypeId:google.maps.MapTypeId.ROADMAP};
        var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
        var marker = new google.maps.Marker({position:myCenter});
        marker.setMap(map);
        }
        </script>
        
    </div>
       
    </div>