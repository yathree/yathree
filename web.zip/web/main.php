<img src="images/img.jpg" clas="img-responsive" alt="HTML5 Icon" width="100%" height="500">
                    <br> <br> <br>
                    <section class="envor-section">
                    <div class="row" style="margin-top: 0px;">
                    <div class="col-sm-6">
                    <h1 style="margin-top: 0px; color:#152E56; text-align: center ">Welcome to Blood donation system  </h1>
                    <p style="text-align:center;font-size: 20px"><span style="color: #152E56; font-family: times">Blood Donation System</span><p>
                      Blood donation is the process of transferring
                      blood from a healthy person to someone who needsit. It "occurs when a person voluntarily has blooddrawn and used for transfusions and/or made intobiopharmaceutical medications by a process calledfractionation.”
                       </p>
                    <p>Blood donation is very important health careand blood is a very unique and precious resourcebecause it only can be obtained from blood donors.Donors participate to save many human beings eachyear, although some still die or suffer because of thelack of access to a safe blood transfusion (WHO,2010).</p>
                    </p>
                    <br>
                    </div>           
                    <div class="col-sm-6">
                    <figure class="single home"><img src="images/dnt.jpg" class="img-responsive" alt="" style="width: 99%; height: 350px;"></figure>
                    </div>
                    </div>
                    </section>
                    <hr>
                    <div class="col-sm-12">
                      <div class="line" style=" height: 3px; width: 99%; background-color: red; box-shadow: 5px 5px 5px #278adb;"></div>
                  </div>
                    <div class="col-sm-4">
                    <div class = "serv">
                    <h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Values</h2>
                    <img src="images/lgo1.jpeg" alt="HTML5 Icon" style="width: 99%; height: 200px;">
                    <p style=" text-align:justify;"> <br> Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
                    </p>
                    <br>
                    </div>
                    </div>
                    <div class="col-sm-4">
                    <div class = "prdt">
                   <h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Mission</h2>      
                    <img src="images/lgo.jpeg" alt="HTML5 Icon" style="width: 99%; height: 200px;">
                    <p style=" text-align:justify;"> <br> Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
                    </p>
                    <br>
                    </div>
                    </div>
                    <div class="col-sm-4">
                    <div class = "prjt">
                   <h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Vision</h2>
                   <img src="images/img2.jpg" alt="HTML5 Icon" style="width: 99%; height: 200px;">

                    <p style=" text-align:justify;">  <br> Service has evolved from a hospital-based system relying on > 80% family replacement donors to a coordinated centralized system based on voluntary non-remunerated blood donors.
                    .</p>
                    <br>
                    </div>
                    </div>