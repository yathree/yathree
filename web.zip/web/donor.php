<section class="envor-section">
    <div class="row" style="margin-top: 0px;">
        <div class="col-sm-6">
            <h1 style="margin-top: 0px; color:#152E56; text-align: center ">Welcome to Blood donation system  </h1>
            <p style="text-align:center;font-size: 20px"><span style="color: #152E56; font-family: times">Blood Donation System</span><p>
              Blood donation is the process of transferring
              blood from a healthy person to someone who needsit. It "occurs when a person voluntarily has blooddrawn and used for transfusions and/or made intobiopharmaceutical medications by a process calledfractionation.”
               </p>
            <p>Blood donation is very important health careand blood is a very unique and precious resourcebecause it only can be obtained from blood donors.Donors participate to save many human beings eachyear, although some still die or suffer because of thelack of access to a safe blood transfusion (WHO,2010).</p>
            </p>
            <br>
            </div>           
            <div class="col-sm-6">
            <figure class="single home"><img src="images/donate-blood.jpg" class="img-responsive" alt="" style="width: 99%; height: 350px;"></figure>
            </div>
            </div>
</section>
        <hr>
        <div class="col-sm-12">
          <div class="line" style=" height: 3px; width: 99%; background-color: red; box-shadow: 5px 5px 5px #278adb;"></div>
  </div>
    <div class="col-sm-4">
    <div class = "serv">
    <h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Why we donate</h2>
    
    <p style=" text-align:justify;">We donate to help people who need a blood transfusion. The act of blood donation produces a feeling of goodwill and a wonderful sense of achievement. It feels really good to think that your actions are directly responsible for saving someone’s life. The gift of life means the difference between life and death for someone. One day that someone may be a close relative, personal friend, a loved one or yourself. 

    </p>
   
    </div>
    </div>
    <div class="col-sm-4">
    <div class = "prdt">
   <h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Who need blood</h2>      
  
   <p style=" text-align:justify;">It is a great feeling to knowing that by donating a unit of blood you have helped
        <ul>
            <li> a mother during complicated child birth</li>
          <!--   <li> a sick baby </li> -->
            <li> a badly injured accident victim </li>
            <li> a patient being treated for cancer </li>
            <li> patients needing major operations </li>
            <li> patients with severe burns </li>
            <li> The life you save may be yours! </li>
           <!--  <li> blood is life </li> -->
        </ul>
    </p>
   
    </div>
    </div>
    <div class="col-sm-4">
    <div class = "prj">
   <h2 class="subsection" style="color:#152E56; font-family: 'Bungee Shade';font-size: 22px;">Importance</h2>
  
    <p style=" text-align:justify;">
    <ul>
       <li>  it carries oxygen to all parts of the body and removes carbon dioxide </li>
       <li>  it provides nutrients to the body’s cells </li>
       <li>  it provides defence against diseases </li>
       <li>  it replaces blood lost from accidents and child birth I would like to encourage all of you to become involved and committed to saving lives. Even if you can’t donate, please encourage others (friends, family) to donate blood. </li>

    </ul>
    
</p>
    
    </div>
    </div>