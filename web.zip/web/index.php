<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<link rel="stylesheet" type="text/css" href="bootstrap/style.css">
<script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="bootstrap/js/popper.min.js"></script>
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

<title>blood</title>
<style>

* {
    box-sizing: border-box;
    font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
    font-size: 16px;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.head {
    /*text-align:center;*/
    color:#152E56;
    /*background-color: #278adb;*/
    font-family: 'Ewert';
    font-weight: bold;
    text-shadow: 2px 2px 2px gray;
}

/*-----------------------------------------------tab color style-------------------------------------*/
.li1{
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
   /*background-color: #278adb;*/
}
li {
    float: left;
}

li a {
    display: block;
    color:blue;
    text-align: center;
    padding: 16px;
    text-decoration:none;
}
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

div.desc {
    padding: 15px;
    text-align: center;
}

* {
    box-sizing: border-box;
}

.responsive {
    padding: 0 6px;
    float: left;
    width: 24%;
}

@media only screen and (max-width: 700px){
    .responsive {
        width: 49%;
        margin: 6px 0;
    }
}

@media only screen and (max-width: 500px){
    .responsive {
        width: 100%;
    }
}

.clearfix:after {
    content: "";
    display: table;
    clear: both;
}


/*-------------------------ending style-----------------------------------*/
</style>
</head>

<body>
  <!--====================================header start=====================================-->

                 <div class="container" style="background: linear-gradient(to left,rgba(180,132,132,0.5)0%, #ffffff 100%);">
                     <div class="row">
                     <div class="col-sm-3"><img src="images/lgo1.jpeg" class="img-circle img-responsive" alt="logo" width="70%"></div>
                     <div class="col-sm-9"><h1 class="head">Zanzibar Blood Donation System</h1> </div>
                    
                     </div> <br>
                     <div class="li1">
                     <ul class="nav nav-tab">
                     <li><a href="#home" id="main" data-toggle="tab">Home</a></li>
                     <li><a href="#donor" id="donor" data-toggle="tab">Why Become Donor</a></li>
                     <li><a href="#centers" id="centers" data-toggle="tab">Where to donate</a></li>
                     <li><a href="#services" id="services" data-toggle="tab">Services</a></li>
                     <li><a href="#register" id="register" data-toggle="tab">Become Donor</a></li>
                     <li><a href="#login" id="login" data-toggle="tab">Login</a></li>
                     <li><a href="#contact" id="contact" data-toggle="tab">Contact Us</a></li>
                    
                     </ul>

                     <script>
                     /* ============================ j query ====================*/
                        $(document).ready(function(){

                          $("#content").load("main.php");


                          $("#contact").click(function(){

                          $("#content").load("map.php");

                            });

                           $("#main").click(function(){

                          $("#content").load("main.php");

                             });

                           $("#register").click(function(){
                           
                            $("#content").load("register.php");
                           
                           });

                           $("#login").click(function(){

                          $("#content").load("login.php");

                            });

                           $("#donor").click(function(){

                            $("#content").load("donor.php")
                           });

                           $("#services").click(function(){

                            $("#content").load("services.php");
                           });

                           $("#centers").click(function(){

                            $("#content").load("centers.php")
                          });
                          });
                    </script>


                   </div>
                 </div>

  <!--=========================================header end=============================================-->

<div class="tab-content">

      <!--======================================home page staring=====================================-->
           
            <div id="home" class="tab-pane fade in active">
              <br>
                    <div class="container" id="content" style="background: linear-gradient(to left, rgba(180,132,132,0.5)0%, #ffffff 100%);">
                   





                </div>
                
          </div>            

<!--============================ending home page====================-->



 <br>
  <div class="container" style=" background: linear-gradient(to left,rgb(180,132,132) 20%, rgb(227,138,134) 90%);"> 

    <div class="col-sm-12">
        <div class="line" style=" height: 5px; background-color: #cccccc;"></div>
    </div>

   <div class="col-sm-12">
      <p style="color:#152E56; text-align: center;  background: linear-gradient(to left,rgb(180,132,132) 20%, rgb(227,138,134) 90%);" > 
        <a href="#">Blood Donation System</a>.<br> © Copyright 2020</p>
    </div>
 </div>


</div>

</body>

</html>
