<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("connection.php");


if(isset($_POST["btnsubmit"])){

	// $fname=$_POST["fname"];
	// $address=$_POST["address"];
	// $gender=$_POST["gender"];
	// $dob=$_POST["dob"];
	// $phone=$_POST["phone"];
	// $email=$_POST["email"];
	   $card=$_POST["card"];

	$check=$con->query("SELECT * FROM donor WHERE cardno='$card'")or die($con->error);
	$check->rowCount();

	if($check->rowCount()<1){

		$sql = "INSERT INTO donor (fullname,address,gender,dob,phone,email,cardno,bloodtype) 
				VALUES(:fullname, :address, :gender, :dob, :phone, :email, :cardno, :bloodtype)";
				
		$stmt=$con->prepare($sql);

		$stmt-> execute(array(
			':fullname' => $_POST["fname"],
			':address' => $_POST["address"],
			':gender' => $_POST["gender"],
			':dob' => $_POST["dob"],
			':phone' => $_POST["phone"],
			':email' => $_POST["email"],
			':cardno' => $_POST["card"],
			':bloodtype' => $_POST["bloodtype"]));

		$sql2 = "INSERT INTO users (username,passwords) 
				VALUES(:username, :passwords)";

		$stmt2=$con->prepare($sql2);

		$stmt2-> execute(array(
			':username' => $_POST["card"],
			':passwords' => $_POST["card"]));

 	?>
 		  <script>
			alert('successfully registered use card number as username and password');
	        window.location.href='index.php';
          </script>

 	<?php
	}
	else{
		?>
 		  <script>
			alert('registed data exist');
	        window.location.href='index.php';
          </script>

 	<?php
	}
}
?>
	